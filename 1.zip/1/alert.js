let money=+prompt("Ваш бюджет на месяц?"),
    time=prompt("Введите дату в формате YYYY-MM-DD"),
    answerFirst = +prompt("Введите обязательную статью расходов в этом месяце"),
    answerFirst1 = +prompt("Введите обязательную статью расходов в этом месяце"),
    answerty = +prompt("Во сколько обойдется?"),
    answerty1 = +prompt("Во сколько обойдется?"),
    appData = {
        Budget : money,
        expenses: {
            answerFirst : answerty,
            answerFirst1 : answerty1,
         },
        optionalExpenses: {
        },
        income: [],
        saving: false
    };
    let exp = appData.expenses.answerFirst + appData.expenses.answerFirst1;
alert("Ваш бюджет на день " + ((money - exp)/30));